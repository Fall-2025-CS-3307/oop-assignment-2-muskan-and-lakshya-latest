#include "Seller.h"
#include <iostream>

void Seller::addProduct() { std::cout << "Product added by seller\n"; }

