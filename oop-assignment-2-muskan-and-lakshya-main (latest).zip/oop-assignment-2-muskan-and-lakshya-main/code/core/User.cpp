#include "User.h"
#include <iostream>

void User::login()  { std::cout << username << " logged in\n"; }
void User::logout() { std::cout << username << " logged out\n"; }

