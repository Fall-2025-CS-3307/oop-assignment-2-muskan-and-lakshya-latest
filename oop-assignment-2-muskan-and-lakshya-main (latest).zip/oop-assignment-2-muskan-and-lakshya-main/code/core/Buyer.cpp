#include "Buyer.h"
#include <iostream>

void Buyer::addToCart() { std::cout << "Item added to cart\n"; }
void Buyer::checkout()  { std::cout << "Checkout complete\n"; }

