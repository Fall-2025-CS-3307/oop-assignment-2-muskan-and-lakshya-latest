#include "Order.h"
// Simple struct; no implementation needed yet

