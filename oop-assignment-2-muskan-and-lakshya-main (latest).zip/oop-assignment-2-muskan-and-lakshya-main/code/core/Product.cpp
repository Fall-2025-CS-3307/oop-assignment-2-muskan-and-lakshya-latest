#include "Product.h"
// No logic yet – struct definition only

